package com.example.uninest.model;

public class HomeAlert {
    private String id;
    private String title;
    private String subtitle;
    private String type;
    private long createdAt;
    private long eventTime;

    public HomeAlert() {}

    public HomeAlert(String id, String title, String subtitle, String type, long createdAt, long eventTime) {
        this.id = id;
        this.title = title;
        this.subtitle = subtitle;
        this.type = type;
        this.createdAt = createdAt;
        this.eventTime = eventTime;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }

    public void setSubtitle(String subtitle) {
        this.subtitle = subtitle;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(long createdAt) {
        this.createdAt = createdAt;
    }

    public long getEventTime() {
        return eventTime;
    }

    public void setEventTime(long eventTime) {
        this.eventTime = eventTime;
    }
}